// SPDX-License-Identifier: GPL-3.0-only
#include "voice_model.h"
#include <stdio.h>
#include <string.h>
static bool identifier(const char *s,size_t max)
{
    size_t n=0;
    for (;n<max && s[n];++n) {
        unsigned char c=(unsigned char)s[n];
        if (!((c>='a'&&c<='z') || (c>='A'&&c<='Z') || (c>='0'&&c<='9') || c=='-')) return false;
    }
    return n && n<max && s[0]!='-' && s[n-1]!='-';
}
void tt_voice_defaults(tt_voice_config_t *c)
{
    memset(c,0,sizeof(*c)); c->version=1; strcpy(c->voice,"Tina");
}
bool tt_voice_valid(const tt_voice_config_t *c)
{
    if (c->version!=1 || !identifier(c->workspace,sizeof(c->workspace)) ||
        !identifier(c->voice,sizeof(c->voice))) return false;
    size_t n=0;
    for (;n<sizeof(c->key) && c->key[n];++n)
        if ((unsigned char)c->key[n]<33 || (unsigned char)c->key[n]>126) return false;
    return n>=16 && n<sizeof(c->key);
}
bool tt_voice_url(const tt_voice_config_t *c,char *out,size_t cap)
{
    if (!tt_voice_valid(c)) return false;
    int n=snprintf(out,cap,"wss://%s.%s.maas.aliyuncs.com/api-ws/v1/realtime?model=" TT_VOICE_MODEL,
                   c->workspace,c->singapore?"ap-southeast-1":"cn-beijing");
    return n>0 && (size_t)n<cap;
}
