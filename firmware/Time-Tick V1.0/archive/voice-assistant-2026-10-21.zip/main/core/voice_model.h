// SPDX-License-Identifier: GPL-3.0-only
#pragma once
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#define TT_VOICE_MODEL "qwen3.8-omni-flash-realtime"
typedef struct {
    uint32_t version;
    bool enabled,wake,singapore;
    char workspace[64],key[192],voice[48];
} tt_voice_config_t;
typedef enum { TT_VOICE_IDLE,TT_VOICE_LISTENING,TT_VOICE_CONNECTING,TT_VOICE_THINKING,
               TT_VOICE_SPEAKING,TT_VOICE_ERROR } tt_voice_phase_t;
typedef struct {
    tt_voice_phase_t phase;
    bool configured,enabled,wake,simulated,portal;
    unsigned level;
    char status[112],reply[768],url[80],code[7];
} tt_voice_view_t;
void tt_voice_defaults(tt_voice_config_t *config);
bool tt_voice_valid(const tt_voice_config_t *config);
bool tt_voice_url(const tt_voice_config_t *config,char *url,size_t capacity);
