// SPDX-License-Identifier: GPL-3.0-only
/* Half-duplex Qwen Realtime: local wake -> bounded recording -> TLS response.
 * The interaction task owns codecs. The network task never touches I2S/LVGL. */
#include "voice.h"
#include "interaction.h"
#include "esp_websocket_client.h"
#include "esp_crt_bundle.h"
#include "esp_http_server.h"
#include "esp_netif.h"
#include "esp_timer.h"
#include "esp_random.h"
#include "esp_heap_caps.h"
#include "esp_wn_iface.h"
#include "esp_wn_models.h"
#include "model_path.h"
#include "nvs.h"
#include "cJSON.h"
#include "mbedtls/base64.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/queue.h"
#include "freertos/semphr.h"
#include <stdatomic.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define RECORD_SAMPLES (16000*8)
#define REPLY_BYTES (24000*2*40)
#define EVENT_BYTES 65536
static SemaphoreHandle_t lock;
static QueueHandle_t jobs;
static tt_voice_config_t config;
static tt_voice_view_t view;
static atomic_bool allowed,busy,cancelled,net_active,start_request;
static atomic_int phase;
static atomic_uint playback_volume;
static int16_t *recording,*reply_pcm;
static size_t recorded,reply_size,played;
static unsigned silence_samples;
static bool heard_speech;
static const esp_wn_iface_t *wake_iface;
static model_iface_data_t *wake_model;
static bool wake_failed;
static int64_t wake_retry;
static httpd_handle_t server;
static int64_t portal_until;
static unsigned portal_failures;
static char portal_code[7];
extern const uint8_t wake_data[] asm("_binary_wake_model_bin_start");
extern const char portal_html[] asm("_binary_voice_portal_html_start");
extern const char portal_end[] asm("_binary_voice_portal_html_end");

static void status(tt_voice_phase_t p,const char *s)
{
    atomic_store(&phase,p);
    xSemaphoreTake(lock,portMAX_DELAY);
    snprintf(view.status,sizeof(view.status),"%s",s);
    if (p!=TT_VOICE_LISTENING) view.level=0;
    xSemaphoreGive(lock);
}
static tt_voice_config_t get_config(void)
{
    tt_voice_config_t c;
    xSemaphoreTake(lock,portMAX_DELAY); c=config; xSemaphoreGive(lock); return c;
}
static bool save_config(const tt_voice_config_t *c)
{
    nvs_handle_t nvs;
    if (nvs_open("tt_voice",NVS_READWRITE,&nvs)!=ESP_OK) return false;
    esp_err_t e=nvs_set_blob(nvs,"config",c,sizeof(*c));
    if (e==ESP_OK) e=nvs_commit(nvs);
    nvs_close(nvs);
    if (e!=ESP_OK) return false;
    tt_voice_cancel();
    xSemaphoreTake(lock,portMAX_DELAY); config=*c; xSemaphoreGive(lock);
    return true;
}
void tt_voice_cancel(void)
{
    atomic_store(&cancelled,true); atomic_store(&start_request,false);
}
void tt_voice_allow(bool on,unsigned volume)
{
    if (atomic_exchange(&allowed,on) && !on) tt_voice_cancel();
    atomic_store(&playback_volume,volume>80?80:volume);
}
void tt_voice_start_talk(void)
{
    if (lock && atomic_load(&allowed) && !atomic_load(&busy) && !atomic_load(&net_active)) atomic_store(&start_request,true);
}
void tt_voice_test(void)
{
    if (!lock || !atomic_load(&allowed) || atomic_load(&net_active)) return;
    tt_voice_config_t c=get_config();
    if (!tt_voice_valid(&c)) { status(TT_VOICE_ERROR,"请先保存地域、业务空间和密钥"); return; }
    bool expected=false;
    if (!atomic_compare_exchange_strong(&busy,&expected,true)) return;
    atomic_store(&cancelled,false); atomic_store(&net_active,true);
    bool test=true;
    status(TT_VOICE_CONNECTING,"正在验证服务连接，不发送录音");
    if (xQueueSend(jobs,&test,0)!=pdTRUE) { atomic_store(&net_active,false); atomic_store(&busy,false); }
}
void tt_voice_snapshot(tt_voice_view_t *v)
{
    if (!lock) { memset(v,0,sizeof(*v)); snprintf(v->status,sizeof(v->status),"语音服务未启动"); return; }
    xSemaphoreTake(lock,portMAX_DELAY);
    *v=view; v->configured=tt_voice_valid(&config); v->enabled=config.enabled; v->wake=config.wake;
    v->portal=portal_until>esp_timer_get_time() && portal_failures<10;
    if (!v->portal) { v->url[0]=0; v->code[0]=0; }
    v->phase=atomic_load(&phase);
    xSemaphoreGive(lock);
}

typedef struct {
    char *event;
    size_t used;
    atomic_bool created,updated,committed,done,failed;
} session_t;
static void receive_event(session_t *s)
{
    cJSON *j=cJSON_Parse(s->event);
    const cJSON *type=cJSON_GetObjectItemCaseSensitive(j,"type");
    if (!cJSON_IsString(type)) { cJSON_Delete(j); atomic_store(&s->failed,true); return; }
    const char *t=type->valuestring;
    if (!strcmp(t,"session.created")) atomic_store(&s->created,true);
    else if (!strcmp(t,"session.updated")) atomic_store(&s->updated,true);
    else if (!strcmp(t,"input_audio_buffer.committed")) atomic_store(&s->committed,true);
    else if (!strcmp(t,"error")) atomic_store(&s->failed,true); /* Never log server payloads/credentials. */
    else if (!strcmp(t,"response.done")) {
        const cJSON *r=cJSON_GetObjectItemCaseSensitive(j,"response");
        const cJSON *st=cJSON_GetObjectItemCaseSensitive(r,"status");
        if (cJSON_IsString(st) && strcmp(st->valuestring,"completed")) atomic_store(&s->failed,true);
        atomic_store(&s->done,true);
    } else if (!strcmp(t,"response.audio.delta")) {
        const cJSON *d=cJSON_GetObjectItemCaseSensitive(j,"delta"); size_t bytes=0;
        if (!cJSON_IsString(d) || !reply_pcm ||
            mbedtls_base64_decode((unsigned char *)reply_pcm+reply_size,REPLY_BYTES-reply_size,&bytes,
                (unsigned char *)d->valuestring,strlen(d->valuestring))!=0) atomic_store(&s->failed,true);
        else reply_size+=bytes;
    } else if (!strcmp(t,"response.audio_transcript.delta") || !strcmp(t,"response.text.delta")) {
        const cJSON *d=cJSON_GetObjectItemCaseSensitive(j,"delta");
        if (cJSON_IsString(d)) {
            xSemaphoreTake(lock,portMAX_DELAY);
            size_t n=strlen(view.reply),add=strlen(d->valuestring);
            /* Append complete deltas only, never cut a UTF-8 character. */
            if (n+add<sizeof(view.reply)) memcpy(view.reply+n,d->valuestring,add+1);
            xSemaphoreGive(lock);
        }
    }
    cJSON_Delete(j);
}
static void socket_event(void *arg,esp_event_base_t base,int32_t id,void *data)
{
    (void)base; session_t *s=arg;
    if (atomic_load(&cancelled)) return;
    if (id==WEBSOCKET_EVENT_ERROR || id==WEBSOCKET_EVENT_DISCONNECTED) {
        if (!atomic_load(&s->done)) atomic_store(&s->failed,true);
    }
    if (id!=WEBSOCKET_EVENT_DATA) return;
    esp_websocket_event_data_t *e=data;
    if (e->op_code!=1 && e->op_code!=0) return; /* Ignore ping/pong/control frames. */
    if (e->payload_offset==0 && e->op_code==1) s->used=0;
    if (e->data_len<0 || s->used+(size_t)e->data_len>=EVENT_BYTES) { atomic_store(&s->failed,true); return; }
    memcpy(s->event+s->used,e->data_ptr,(size_t)e->data_len); s->used+=(size_t)e->data_len;
    if (e->fin && e->payload_offset+e->data_len==e->payload_len) {
        s->event[s->used]=0; receive_event(s); s->used=0;
    }
}
static bool await_event(session_t *s,atomic_bool *event,unsigned timeout_ms)
{
    int64_t end=esp_timer_get_time()+(int64_t)timeout_ms*1000;
    while (!atomic_load(event) && !atomic_load(&s->failed) && !atomic_load(&cancelled) && esp_timer_get_time()<end)
        vTaskDelay(pdMS_TO_TICKS(20));
    return atomic_load(event) && !atomic_load(&s->failed) && !atomic_load(&cancelled);
}
static bool send_json(esp_websocket_client_handle_t ws,const char *json)
{
    if (atomic_load(&cancelled)) return false;
    size_t n=strlen(json);
    return esp_websocket_client_send_text(ws,json,(int)n,pdMS_TO_TICKS(1500))==(int)n;
}
static void network_worker(void *arg)
{
    (void)arg; bool test;
    for (;;) {
        xQueueReceive(jobs,&test,portMAX_DELAY);
        tt_voice_config_t c=get_config(); char url[256],auth[224],session_json[1024];
        session_t s={0}; bool ok=false;
        s.event=heap_caps_malloc(EVENT_BYTES,MALLOC_CAP_SPIRAM|MALLOC_CAP_8BIT);
        if (!s.event || !tt_voice_url(&c,url,sizeof(url))) goto done;
        snprintf(auth,sizeof(auth),"Authorization: Bearer %s\r\n",c.key);
        esp_websocket_client_config_t wc={.uri=url,.headers=auth,.crt_bundle_attach=esp_crt_bundle_attach,
            .disable_auto_reconnect=true,.network_timeout_ms=3000,.buffer_size=4096,.task_stack=8192};
        esp_websocket_client_handle_t ws=esp_websocket_client_init(&wc);
        if (!ws) goto done;
        reply_size=played=0;
        esp_websocket_register_events(ws,WEBSOCKET_EVENT_ANY,socket_event,&s);
        if (esp_websocket_client_start(ws)!=ESP_OK || !await_event(&s,&s.created,15000)) goto close;
        snprintf(session_json,sizeof(session_json),
            "{\"type\":\"session.update\",\"session\":{\"modalities\":[\"text\",\"audio\"],"
            "\"instructions\":\"你是Time-Tick的温柔专注助手。使用简洁中文回答，每次不超过两句话。\","
            "\"turn_detection\":null,\"audio\":{\"input\":{\"format\":{\"type\":\"pcm\",\"sample_rate\":16000,"
            "\"sample_format\":\"s16le\",\"channels\":1,\"packing\":\"interleaved\",\"channel_layout\":\"mono\"}},"
            "\"output\":{\"voice\":\"%s\",\"format\":{\"type\":\"pcm\",\"sample_rate\":24000}}}}}",c.voice);
        if (!send_json(ws,session_json) || !await_event(&s,&s.updated,8000)) goto close;
        if (test) { ok=true; goto close; }
        char *event=malloc(4400);
        if (!event) goto close;
        const char *prefix="{\"type\":\"input_audio_buffer.append\",\"audio\":\"";
        size_t pre=strlen(prefix); bool sent=true;
        for (size_t at=0;sent && at<recorded*2;at+=3200) {
            size_t n=recorded*2-at; if (n>3200) n=3200;
            size_t encoded=0; memcpy(event,prefix,pre);
            if (mbedtls_base64_encode((unsigned char *)event+pre,4400-pre-3,&encoded,
                                     (unsigned char *)recording+at,n)!=0) { sent=false; break; }
            memcpy(event+pre+encoded,"\"}",3); sent=send_json(ws,event);
        }
        free(event);
        if (!sent || !send_json(ws,"{\"type\":\"input_audio_buffer.commit\"}") ||
            !await_event(&s,&s.committed,5000) || !send_json(ws,"{\"type\":\"response.create\"}")) goto close;
        status(TT_VOICE_THINKING,"千问正在思考…");
        ok=await_event(&s,&s.done,30000);
close:
        esp_websocket_client_stop(ws);
        esp_websocket_client_destroy(ws); /* joins event task before session storage is freed */
done:
        memset(c.key,0,sizeof(c.key)); memset(auth,0,sizeof(auth)); free(s.event);
        if (recording) memset(recording,0,recorded*2);
        recorded=0;
        bool speaking=ok && !test && !atomic_load(&cancelled) && reply_size && !(reply_size%2);
        if (atomic_load(&cancelled)) { reply_size=0; status(TT_VOICE_IDLE,"对话已停止"); }
        else if (!ok) { reply_size=0; status(TT_VOICE_ERROR,"连接失败：请检查网络、地域、空间、密钥及模型权限"); }
        else if (test) { status(TT_VOICE_IDLE,"服务连接成功，可以开始对话"); }
        else if (reply_size && !(reply_size%2)) status(TT_VOICE_SPEAKING,"千问正在回答…");
        else { status(TT_VOICE_IDLE,"回复完成"); }
        atomic_store(&net_active,false);
        if (!speaking) atomic_store(&busy,false);
    }
}
static bool audio_buffers(void)
{
    if (!recording) recording=heap_caps_malloc(RECORD_SAMPLES*2,MALLOC_CAP_SPIRAM|MALLOC_CAP_8BIT);
    if (!reply_pcm) reply_pcm=heap_caps_malloc(REPLY_BYTES,MALLOC_CAP_SPIRAM|MALLOC_CAP_8BIT);
    return recording && reply_pcm;
}
static bool wake_ready(void)
{
    if (wake_model) return true;
    if (wake_failed) return false;
    srmodel_list_t *models=srmodel_load(wake_data);
    char *name=models?esp_srmodel_filter(models,ESP_WN_PREFIX,"nihaoxiaozhi"):NULL;
    wake_iface=name?esp_wn_handle_from_name(name):NULL;
    if (wake_iface) wake_model=wake_iface->create(name,DET_MODE_90);
    if (!wake_model || wake_iface->get_samp_rate(wake_model)!=16000 ||
        wake_iface->get_channel_num(wake_model)!=1 || wake_iface->get_samp_chunksize(wake_model)>1024) {
        wake_failed=true; status(TT_VOICE_ERROR,"唤醒模型不可用，请使用开始对话"); return false;
    }
    return true;
}
unsigned tt_voice_poll_delay_ms(void)
{
    if (!lock || !atomic_load(&allowed)) return 20;
    if (atomic_load(&start_request)) return 1;
    if (atomic_load(&net_active)) return 20;
    if (atomic_load(&busy)) return 1;
    xSemaphoreTake(lock,portMAX_DELAY);
    bool wake=config.enabled && config.wake && tt_voice_valid(&config);
    xSemaphoreGive(lock);
    return wake && !wake_failed && esp_timer_get_time()>=wake_retry?1:20;
}
void tt_voice_audio_step(void)
{
    if (!lock) return;
    if (!atomic_load(&allowed) || (atomic_load(&cancelled) && atomic_load(&busy))) {
        tt_audio_idle();
        if (!atomic_load(&net_active)) {
            if (recording) memset(recording,0,recorded*2);
            recorded=reply_size=played=0; atomic_store(&busy,false);
            if (atomic_load(&phase)!=TT_VOICE_ERROR) status(TT_VOICE_IDLE,"对话已停止");
        }
        return;
    }
    tt_voice_config_t c=get_config();
    bool configured=tt_voice_valid(&c);
    memset(c.key,0,sizeof(c.key));
    if (atomic_exchange(&start_request,false)) {
        if (!configured || !c.enabled) { status(TT_VOICE_ERROR,"请先配置并启用语音助手"); return; }
        bool expected=false;
        if (atomic_compare_exchange_strong(&busy,&expected,true)) {
            if (!audio_buffers()) { status(TT_VOICE_ERROR,"语音内存不足"); atomic_store(&busy,false); return; }
            atomic_store(&cancelled,false); recorded=0; silence_samples=0; heard_speech=false;
            xSemaphoreTake(lock,portMAX_DELAY); view.reply[0]=0; xSemaphoreGive(lock);
            status(TT_VOICE_LISTENING,"请说话，说完稍停即可（最长 8 秒）");
        }
    }
    int p=atomic_load(&phase);
    if (atomic_load(&busy) && p==TT_VOICE_LISTENING) {
        int16_t pcm[320];
        if (!tt_audio_read16(pcm,320)) {
            tt_audio_idle(); status(TT_VOICE_ERROR,"麦克风不可用"); atomic_store(&busy,false); return;
        }
        unsigned peak=0;
        for (unsigned i=0;i<320;++i) { unsigned a=(unsigned)abs(pcm[i]); if (a>peak) peak=a; }
        xSemaphoreTake(lock,portMAX_DELAY); view.level=peak*100/32768; xSemaphoreGive(lock);
        memcpy(recording+recorded,pcm,sizeof(pcm)); recorded+=320;
        if (peak>900) { heard_speech=true; silence_samples=0; } else silence_samples+=320;
        if (recorded>=RECORD_SAMPLES || (heard_speech && recorded>=16000 && silence_samples>=14400)) {
            tt_audio_idle();
            if (!heard_speech) { memset(recording,0,recorded*2); recorded=0; atomic_store(&busy,false); status(TT_VOICE_IDLE,"没有听清，请再次唤醒或点击开始"); return; }
            bool test=false; atomic_store(&net_active,true); status(TT_VOICE_CONNECTING,"正在连接通义千问…");
            if (xQueueSend(jobs,&test,0)!=pdTRUE) { atomic_store(&net_active,false); atomic_store(&busy,false); status(TT_VOICE_ERROR,"服务忙，请重试"); }
        }
    } else if (atomic_load(&busy) && p==TT_VOICE_SPEAKING && !atomic_load(&net_active)) {
        size_t n=(reply_size-played)/2; if (n>240) n=240;
        if (!tt_audio_write24(reply_pcm+played/2,n,atomic_load(&playback_volume))) {
            tt_audio_idle(); status(TT_VOICE_ERROR,"扬声器不可用"); atomic_store(&busy,false); return;
        }
        played+=n*2;
        if (played>=reply_size) {
            tt_audio_idle(); memset(reply_pcm,0,reply_size); reply_size=played=0;
            atomic_store(&busy,false); wake_retry=esp_timer_get_time()+1500000;
            if (wake_model) wake_iface->clean(wake_model);
            status(TT_VOICE_IDLE,"回复完成，再说“你好小智”可开始下一轮");
        }
    } else if (!atomic_load(&busy) && configured && c.enabled && c.wake && esp_timer_get_time()>=wake_retry) {
        if (!wake_ready()) { tt_audio_idle(); return; }
        int16_t pcm[1024]; size_t n=(size_t)wake_iface->get_samp_chunksize(wake_model);
        if (!tt_audio_read16(pcm,n)) {
            tt_audio_idle(); wake_retry=esp_timer_get_time()+5000000;
            status(TT_VOICE_ERROR,"唤醒麦克风不可用"); return;
        }
        if (wake_iface->detect(wake_model,pcm)>0) {
            wake_iface->clean(wake_model); tt_audio_idle();
            tt_interaction_sound(TT_SOUND_TAP,atomic_load(&playback_volume));
            atomic_store(&start_request,true);
        }
    } else tt_audio_idle();
}

static bool portal_authorized(const char *code)
{
    xSemaphoreTake(lock,portMAX_DELAY);
    bool active=esp_timer_get_time()<portal_until && portal_failures<10;
    bool ok=active && (!code || !strcmp(code,portal_code));
    if (code && active && !ok) ++portal_failures;
    xSemaphoreGive(lock); return ok;
}
static esp_err_t portal_page(httpd_req_t *r)
{
    if (!portal_authorized(NULL)) return httpd_resp_send_err(r,HTTPD_403_FORBIDDEN,"配置已关闭，请在设备上重新打开");
    httpd_resp_set_type(r,"text/html; charset=utf-8");
    httpd_resp_set_hdr(r,"Cache-Control","no-store");
    httpd_resp_set_hdr(r,"Content-Security-Policy","default-src 'self'; script-src 'unsafe-inline'; style-src 'unsafe-inline'; connect-src 'self'; frame-ancestors 'none'");
    return httpd_resp_send(r,portal_html,portal_end-portal_html-1);
}
static bool copy_field(cJSON *j,const char *key,char *out,size_t cap,bool optional)
{
    cJSON *v=cJSON_GetObjectItemCaseSensitive(j,key);
    if (!cJSON_IsString(v) || strlen(v->valuestring)>=cap) return false;
    if (!optional || v->valuestring[0]) strcpy(out,v->valuestring);
    return true;
}
static esp_err_t portal_save(httpd_req_t *r)
{
    char code[16]={0};
    (void)httpd_req_get_hdr_value_str(r,"X-Device-Code",code,sizeof(code));
    if (!portal_authorized(code)) return httpd_resp_send_err(r,HTTPD_403_FORBIDDEN,"验证码错误或已过期");
    if (r->content_len<=0 || r->content_len>1536) return httpd_resp_send_err(r,HTTPD_400_BAD_REQUEST,"配置过长");
    char body[1537]; int at=0;
    while (at<r->content_len) {
        int n=httpd_req_recv(r,body+at,r->content_len-at);
        if (n<=0) return ESP_FAIL;
        at+=n;
    }
    body[at]=0; cJSON *j=cJSON_Parse(body); memset(body,0,sizeof(body));
    const cJSON *action=cJSON_GetObjectItemCaseSensitive(j,"action");
    if (!cJSON_IsString(action)) { cJSON_Delete(j); return httpd_resp_send_err(r,HTTPD_400_BAD_REQUEST,"无效操作"); }
    tt_voice_config_t c=get_config(); bool ok=false; const char *message="配置无效，请检查字段";
    if (!strcmp(action->valuestring,"save")) {
        const cJSON *region=cJSON_GetObjectItemCaseSensitive(j,"region");
        const cJSON *enabled=cJSON_GetObjectItemCaseSensitive(j,"enabled"),*wake=cJSON_GetObjectItemCaseSensitive(j,"wake");
        ok=copy_field(j,"workspace",c.workspace,sizeof(c.workspace),false) &&
           copy_field(j,"voice",c.voice,sizeof(c.voice),false) && copy_field(j,"key",c.key,sizeof(c.key),true) &&
           cJSON_IsString(region) && (!strcmp(region->valuestring,"beijing") || !strcmp(region->valuestring,"singapore")) &&
           cJSON_IsBool(enabled) && cJSON_IsBool(wake);
        if (ok) {
            c.singapore=!strcmp(region->valuestring,"singapore"); c.enabled=cJSON_IsTrue(enabled); c.wake=cJSON_IsTrue(wake);
            ok=tt_voice_valid(&c) && save_config(&c);
            if (ok) { message="已保存。请测试连接，然后在设备上开始对话。"; status(TT_VOICE_IDLE,"配置已保存，请测试连接"); }
        }
    } else if (!strcmp(action->valuestring,"clear")) {
        tt_voice_defaults(&c); ok=save_config(&c); message=ok?"已清除语音配置":"保存失败";
    } else if (!strcmp(action->valuestring,"test")) {
        ok=tt_voice_valid(&c) && atomic_load(&allowed) && !atomic_load(&busy);
        if (ok) { tt_voice_test(); message="已开始测试，请查看设备屏幕上的连接结果。"; }
        else message="请先保存配置，并将设备正放、结束当前对话后重试。";
    }
    memset(c.key,0,sizeof(c.key)); cJSON_Delete(j);
    httpd_resp_set_hdr(r,"Cache-Control","no-store"); httpd_resp_set_type(r,"text/plain; charset=utf-8");
    if (!ok) httpd_resp_set_status(r,"400 Bad Request");
    return httpd_resp_sendstr(r,message);
}
void tt_voice_portal_open(void)
{
    if (!lock) return;
    esp_netif_ip_info_t ip; esp_netif_t *net=esp_netif_get_handle_from_ifkey("WIFI_STA_DEF");
    if (!net || esp_netif_get_ip_info(net,&ip)!=ESP_OK || !ip.ip.addr) { status(TT_VOICE_ERROR,"请先连接 Wi-Fi，再打开手机配置"); return; }
    tt_voice_cancel();
    if (!server) {
        httpd_config_t h=HTTPD_DEFAULT_CONFIG(); h.server_port=8080; h.ctrl_port=32770; h.stack_size=6144;
        h.lru_purge_enable=true; h.max_open_sockets=3;
        if (httpd_start(&server,&h)!=ESP_OK) { server=NULL; status(TT_VOICE_ERROR,"配置服务启动失败"); return; }
        httpd_uri_t root={.uri="/",.method=HTTP_GET,.handler=portal_page};
        httpd_uri_t api={.uri="/api/voice",.method=HTTP_POST,.handler=portal_save};
        httpd_register_uri_handler(server,&root); httpd_register_uri_handler(server,&api);
    }
    xSemaphoreTake(lock,portMAX_DELAY);
    snprintf(portal_code,sizeof(portal_code),"%06lu",(unsigned long)(esp_random()%1000000));
    portal_until=esp_timer_get_time()+600000000; portal_failures=0;
    snprintf(view.url,sizeof(view.url),"http://" IPSTR ":8080",IP2STR(&ip.ip));
    strcpy(view.code,portal_code); xSemaphoreGive(lock);
    status(TT_VOICE_IDLE,"同一 Wi-Fi 下打开网址，输入验证码配置");
}
bool tt_voice_init(void)
{
    lock=xSemaphoreCreateMutex(); jobs=xQueueCreate(1,sizeof(bool));
    if (!lock || !jobs) {
        if (lock) vSemaphoreDelete(lock);
        if (jobs) vQueueDelete(jobs);
        lock=NULL; jobs=NULL; return false;
    }
    tt_voice_defaults(&config);
    nvs_handle_t nvs;
    if (nvs_open("tt_voice",NVS_READONLY,&nvs)==ESP_OK) {
        tt_voice_config_t loaded; size_t n=sizeof(loaded);
        if (nvs_get_blob(nvs,"config",&loaded,&n)==ESP_OK && n==sizeof(loaded) && tt_voice_valid(&loaded)) config=loaded;
        memset(&loaded,0,sizeof(loaded)); nvs_close(nvs);
    }
    status(TT_VOICE_IDLE,"打开手机配置，接入通义千问");
    if (xTaskCreate(network_worker,"tt_qwen",8192,NULL,3,NULL)==pdPASS) return true;
    vSemaphoreDelete(lock); vQueueDelete(jobs); lock=NULL; jobs=NULL; return false;
}
