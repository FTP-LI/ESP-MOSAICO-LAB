// SPDX-License-Identifier: GPL-3.0-only
#pragma once
#include "voice_model.h"
#ifdef ESP_PLATFORM
bool tt_voice_init(void);
void tt_voice_start_talk(void);
void tt_voice_test(void);
void tt_voice_cancel(void);
void tt_voice_allow(bool allowed,unsigned volume);
void tt_voice_portal_open(void);
void tt_voice_snapshot(tt_voice_view_t *view);
/* Called exclusively by the audio owner task. */
void tt_voice_audio_step(void);
unsigned tt_voice_poll_delay_ms(void);
#endif
