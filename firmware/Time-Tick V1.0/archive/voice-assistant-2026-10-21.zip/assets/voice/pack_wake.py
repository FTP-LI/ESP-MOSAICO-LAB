"""Pack one unmodified official ESP-SR model using its own packer."""
from pathlib import Path
import sys, tempfile, shutil
sr=Path(sys.argv[1]).resolve(); out=Path(sys.argv[2]).resolve()
sys.path.insert(0,str(sr/'model'))
from pack_model import pack_models
out.parent.mkdir(parents=True,exist_ok=True)
with tempfile.TemporaryDirectory() as folder:
    shutil.copytree(sr/'model/wakenet_model/wn9s_nihaoxiaozhi',Path(folder)/'wn9s_nihaoxiaozhi')
    pack_models(folder,'wake_model.bin')
    data=(Path(folder)/'wake_model.bin').read_bytes()
    if not out.exists() or out.read_bytes()!=data: out.write_bytes(data)
