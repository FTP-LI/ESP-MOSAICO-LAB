// SPDX-License-Identifier: GPL-3.0-only
#include "scene_model.h"
#include "voice_model.h"
#include <assert.h>
#include <string.h>
#include <stdio.h>
int main(void)
{
    assert(tt_scene_for_time(1,22,false).season==TT_WINTER);
    assert(tt_scene_for_time(3,6,false).season==TT_SPRING);
    assert(tt_scene_for_time(7,12,false).season==TT_SUMMER);
    assert(tt_scene_for_time(10,18,false).season==TT_AUTUMN);
    assert(tt_scene_for_time(1,22,true).season==TT_SUMMER);
    assert(tt_scene_for_time(3,6,false).daylight==TT_DAWN);
    assert(tt_scene_for_time(3,12,false).daylight==TT_DAY);
    assert(tt_scene_for_time(3,18,false).daylight==TT_DUSK);
    assert(tt_scene_for_time(3,22,false).daylight==TT_NIGHT);
    tt_voice_config_t c; tt_voice_defaults(&c);
    assert(!tt_voice_valid(&c));
    assert(!strcmp(c.voice,"Tina") && !c.enabled && !c.wake);
    strcpy(c.workspace,"test-space"); strcpy(c.key,"test-placeholder-not-a-real-key");
    assert(tt_voice_valid(&c)); char url[256];
    assert(tt_voice_url(&c,url,sizeof(url)));
    assert(strstr(url,"wss://test-space.cn-beijing.maas.aliyuncs.com/")==url);
    c.singapore=true; assert(tt_voice_url(&c,url,sizeof(url)));
    assert(strstr(url,"ap-southeast-1.maas.aliyuncs.com"));
    assert(!tt_voice_url(&c,url,10));
    strcpy(c.workspace,"evil.example/path"); assert(!tt_voice_valid(&c));
    strcpy(c.workspace,"valid"); strcpy(c.key,"key\r\nInjected: header"); assert(!tt_voice_valid(&c));
    memset(c.key,'k',sizeof(c.key)); assert(!tt_voice_valid(&c));
    strcpy(c.key,"test-placeholder-not-a-real-key");
    strcpy(c.voice,"\"},\"inject\":true"); assert(!tt_voice_valid(&c));
    puts("PASS: seasonal/daylight mapping, credential bounds and endpoint/header/JSON injection rejection");
    return 0;
}
