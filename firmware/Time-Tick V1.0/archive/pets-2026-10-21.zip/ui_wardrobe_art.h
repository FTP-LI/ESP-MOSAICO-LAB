#pragma once
#include "lvgl.h"
extern const lv_image_dsc_t *const tt_art_idle[3][6];
extern const lv_image_dsc_t *const tt_art_clothes[6][2];
extern const lv_image_dsc_t *const tt_art_autumn[3][3][6];
