#pragma once
#include "lvgl.h"
extern const lv_image_dsc_t *const tt_art_pets[3][3];
extern const lv_image_dsc_t *const tt_art_motion[3][5][6];
