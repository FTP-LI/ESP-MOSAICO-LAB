// SPDX-License-Identifier: GPL-3.0-only
#include "ui_sprite.h"
#include "ui_theme.h"
#include "ui_art.h"
#include "ui_wardrobe_art.h"
#include "ui_text.h"
#include <stdlib.h>
typedef struct {
    lv_obj_t *obj,*image,*heart,*clothes; lv_timer_t *timer;
    tt_pet_t type; tt_animation_t animation;
    uint32_t heart_started; bool heart_visible;
    const lv_image_dsc_t *source;
    bool environment; tt_weather_kind_t weather; tt_scene_t scene;
} sprite_t;
static bool autumn_outfit(const sprite_t *p)
{
    return p->environment && p->scene.season==TT_AUTUMN && p->scene.daylight!=TT_NIGHT &&
        p->weather!=TT_WEATHER_RAIN && p->weather!=TT_WEATHER_STORM && p->weather!=TT_WEATHER_SNOW;
}
static void outfit(sprite_t *p,tt_animation_clip_t clip,unsigned frame,int dy)
{
    bool sleeping=clip==TT_ANIM_SLEEP,walking=clip==TT_ANIM_WALK;
    if (!p->environment || autumn_outfit(p) || tt_animation_duration(clip) || clip==TT_ANIM_HAPPY || sleeping) {
        lv_obj_add_flag(p->clothes,LV_OBJ_FLAG_HIDDEN); return;
    }
    int item=p->weather==TT_WEATHER_RAIN || p->weather==TT_WEATHER_STORM?4:
        p->scene.daylight==TT_NIGHT?5:p->weather==TT_WEATHER_SNOW || p->scene.season==TT_WINTER?3:
        p->scene.season==TT_SPRING?0:p->scene.season==TT_SUMMER?1:2;
    if (!walking && frame==4) { lv_obj_add_flag(p->clothes,LV_OBJ_FLAG_HIDDEN); return; }
    bool hat=item==1 || item==3 || item==5;
    int cx=walking?(p->type==TT_CHICK?62:74):54;
    int cy=hat?(walking?26:15):(walking?(p->type==TT_CHICK?63:59):66);
    if (item==4 && walking) { cx-=14; cy+=4; }
    if (walking && p->animation.left) cx=104-cx;
    /* Head turn frame follows the right-facing profile; stretch leaves the face clear. */
    if (!walking && frame==3) cx+=5;
    const lv_image_dsc_t *source=tt_art_clothes[item][walking && p->animation.left?1:0];
    if (lv_image_get_src(p->clothes)!=source) lv_image_set_src(p->clothes,source);
    if (hat && cy<(int)source->header.h/2+3) cy=(int)source->header.h/2+3;
    lv_obj_set_pos(p->clothes,cx-(int)source->header.w/2,cy+dy-(hat?(int)source->header.h/2:3));
    lv_obj_remove_flag(p->clothes,LV_OBJ_FLAG_HIDDEN);
}
static void render(sprite_t *p)
{
    unsigned frame=tt_animation_frame(&p->animation,lv_tick_get());
    tt_animation_clip_t clip=p->animation.clip;
    if (tt_animation_duration(clip) && !tt_sprite_busy(p->obj)) clip=TT_ANIM_IDLE;
    const lv_image_dsc_t *source;
    if (clip==TT_ANIM_WALK) source=tt_art_motion[p->type][p->animation.left?4:0][frame];
    else if (clip>=TT_ANIM_EAT) source=tt_art_motion[p->type][clip-TT_ANIM_EAT+1][frame];
    else if (clip==TT_ANIM_IDLE && p->environment) {
        unsigned age=(lv_tick_get()+p->type*1193)%12000;
        frame=age<2700?0:age<2830?1:age<2970?2:age<3100?1:age<5900?0:age<7200?3:age<9500?0:age<10200?4:5;
        source=tt_art_idle[p->type][frame];
    } else source=tt_art_pets[p->type][clip==TT_ANIM_HAPPY?1:clip==TT_ANIM_SLEEP?2:0];
    /* Costume is painted into the pose so ears, fur and raised paws correctly
     * occlude the scarf. Both walking directions use the same mirrored frame. */
    if (autumn_outfit(p) && (clip==TT_ANIM_IDLE || clip==TT_ANIM_WALK))
        source=tt_art_autumn[p->type][clip==TT_ANIM_IDLE?0:p->animation.left?2:1][frame];
    if (source!=p->source) { p->source=source; lv_image_set_src(p->image,source); }
    int breath=lv_trigo_sin((int)(lv_tick_get()%3600)/10)*2/LV_TRIGO_SIN_MAX;
    int dy=clip==TT_ANIM_WALK?(frame%3==1?-1:0):clip==TT_ANIM_IDLE || clip==TT_ANIM_SLEEP?-abs(breath):0;
    lv_obj_set_y(p->image,dy);
    outfit(p,clip,frame,dy);
}
static void tick(lv_timer_t *t)
{
    sprite_t *p=lv_timer_get_user_data(t);
    if (!lv_obj_is_visible(p->obj)) return;
    render(p);
    uint32_t age=lv_tick_get()-p->heart_started;
    bool visible=p->heart_visible && age<2000;
    lv_obj_set_style_opa(p->heart,visible?LV_OPA_COVER:LV_OPA_TRANSP,0);
    if (visible) lv_obj_set_y(p->heart,8-(int)(age/160));
}
static void deleted(lv_event_t *e)
{
    sprite_t *p=lv_event_get_user_data(e); lv_timer_delete(p->timer); lv_free(p);
}
lv_obj_t *tt_sprite_create(lv_obj_t *parent,int x,int y,tt_pet_t type)
{
    lv_obj_t *obj=lv_obj_create(parent); lv_obj_remove_style_all(obj);
    lv_obj_set_pos(obj,x,y); lv_obj_set_size(obj,108,104); lv_obj_remove_flag(obj,LV_OBJ_FLAG_SCROLLABLE);
    lv_obj_add_flag(obj,LV_OBJ_FLAG_CLICKABLE);
    sprite_t *p=lv_malloc(sizeof(*p)); LV_ASSERT_MALLOC(p);
    *p=(sprite_t){.obj=obj,.type=type}; lv_obj_set_user_data(obj,p);
    lv_obj_t *shadow=lv_obj_create(obj); lv_obj_remove_style_all(shadow);
    lv_obj_set_pos(shadow,26,91); lv_obj_set_size(shadow,58,8);
    lv_obj_remove_flag(shadow,LV_OBJ_FLAG_CLICKABLE|LV_OBJ_FLAG_SCROLLABLE);
    lv_obj_set_style_bg_color(shadow,lv_color_hex(0x364d32),0); lv_obj_set_style_bg_opa(shadow,LV_OPA_20,0);
    lv_obj_set_style_radius(shadow,LV_RADIUS_CIRCLE,0);
    p->image=lv_image_create(obj); lv_obj_set_pos(p->image,2,0);
    lv_obj_remove_flag(p->image,LV_OBJ_FLAG_CLICKABLE);
    p->clothes=lv_image_create(obj); lv_obj_remove_flag(p->clothes,LV_OBJ_FLAG_CLICKABLE);
    lv_obj_add_flag(p->clothes,LV_OBJ_FLAG_HIDDEN);
    p->heart=lv_label_create(obj); lv_label_set_text(p->heart,"♥");
    lv_obj_set_style_text_font(p->heart,&tt_font_18,0); lv_obj_set_style_text_color(p->heart,lv_color_hex(0xa94f53),0);
    lv_obj_set_pos(p->heart,90,8); lv_obj_set_style_opa(p->heart,LV_OPA_TRANSP,0);
    p->timer=lv_timer_create(tick,50,p);
    lv_obj_add_event_cb(obj,deleted,LV_EVENT_DELETE,p); render(p); return obj;
}
void tt_sprite_set(lv_obj_t *obj,tt_pet_t type,tt_animation_clip_t clip,bool left)
{
    sprite_t *p=lv_obj_get_user_data(obj);
    if (p->type==type && p->animation.clip==clip && p->animation.left==left &&
        !(tt_animation_duration(clip) && !tt_sprite_busy(obj))) return;
    p->type=type;
    tt_animation_set(&p->animation,clip,left,lv_tick_get()); render(p);
}
void tt_sprite_walk(lv_obj_t *obj,uint32_t distance_q8)
{
    sprite_t *p=lv_obj_get_user_data(obj); tt_animation_walk(&p->animation,distance_q8); render(p);
}
void tt_sprite_heart(lv_obj_t *obj)
{
    sprite_t *p=lv_obj_get_user_data(obj); p->heart_started=lv_tick_get(); p->heart_visible=true;
}
bool tt_sprite_busy(lv_obj_t *obj)
{
    sprite_t *p=lv_obj_get_user_data(obj); return tt_animation_busy(&p->animation,lv_tick_get());
}
tt_animation_t tt_sprite_animation(lv_obj_t *obj)
{
    sprite_t *p=lv_obj_get_user_data(obj); return p->animation;
}
void tt_sprite_environment(lv_obj_t *obj,tt_weather_kind_t weather,tt_scene_t scene)
{
    sprite_t *p=lv_obj_get_user_data(obj);
    if (p->environment && p->weather==weather && p->scene.season==scene.season &&
        p->scene.daylight==scene.daylight) return;
    p->environment=true; p->weather=weather; p->scene=scene;
    lv_obj_set_style_image_recolor(p->image,lv_color_hex(0x35476a),0);
    lv_obj_set_style_image_recolor_opa(p->image,scene.daylight==TT_NIGHT?35:0,0);
    render(p);
}
