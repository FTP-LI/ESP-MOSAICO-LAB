#pragma once
#include "lvgl.h"
extern const lv_image_dsc_t tt_art_weather_parasol;
extern const lv_image_dsc_t tt_art_weather_cushion;
