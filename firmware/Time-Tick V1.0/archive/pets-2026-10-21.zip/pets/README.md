# 时光小院美术素材

2026-10-20 使用 Codex 内置 **imagegen** 生成，没有调用本地图片生成 CLI，没有提取《星露谷物语》或其他商业游戏的素材。这些文件标为 AI 生成素材，随项目提供来源与完整提示词。

## 源文件

| 文件 | 内容 |
| --- | --- |
| `garden.png` | 初始庭院参考图；当前背景由 `../weather/` 管理 |
| `pets.png` | 4×3初始姿态表；现在使用站立、开心、睡眠三列 |
| `walk-cycle.png` | 6×3连续步态表；行依次为猫、狗、小鸡 |
| `cat-actions.png`、`dog-actions.png`、`chick-actions.png` | 6×4动作表；使用第二行进食、第三行玩球、第四行洗澡；首行由独立步态表替代 |
| `prompts.json`、`animation-prompts.json` | 初始场景/姿态及本轮动作的完整生成提示词 |
| `convert_assets.py` | 离线切片、对齐、镜像与LVGL格式转换 |

原图不覆盖。待机4×3姿态表此前按均匀网格裁切，狗狗脚下会混入下一行小鸡的冠毛；本轮改为与动作表相同的轮廓提取，参数支持4列/6列。待机姿态与动作现在统一按透明连通区域提取角色和道具，避免相邻行耳朵、脚或跨格小球误切入。每个动作循环使用共同裁切范围与缩放比例，保留抬头、俯身和跳跃的位移，不逐帧强行居中。转换只处理切片、尺寸与格式，不重新绘制形象。

## 生成与检查

在 `Time-Tick V1.0` 目录使用 Python 3 和 Pillow（已验证12.3.0）：

```powershell
python assets/pets/convert_assets.py --proof
```

输出到 `main/generated/ui_art.c`、`ui_art.h`、`ui_motion.c`：9张待机姿态、72张行走/照料帧和18张镜像行走帧。角色均为104×104 ARGB8888，原始像素合计 **4,283,136字节**。背景单独由 [天气素材转换器](../weather/README.md)生成。C数据直接参与PC/固件编译，无需文件系统、PNG解码器或运行时联网。

`--proof` 在忽略的 `build-assets/` 输出三张逐帧总览和GIF循环供检查；省略参数只生成C数据。旧的背景缩略图和分散单帧导出已移除，避免多处维护相同资源。修改源图后运行转换器，再按F5编译预览。

每个步态六帧，实际移动48像素才完成一次循环，静止时不会原地滑步。进食六帧循环两次（1.8秒），玩耍、洗澡各循环三次（2.7秒），之后恢复自主活动。PC与固件共用 `core/pet_animation.*` 和 `ui/ui_sprite.*`。

六类天气下的行为与小道具见 [天气道具](weather/README.md)。雨伞和软垫使用独立透明插画，不修改三种伙伴的原始形象或动作表。

## 季节换装与待机帧

`wardrobe/idle.png` 为3行×6列的新待机帧，其中狗狗行使用重新生成、留有独立间隔的 `wardrobe/idle-dog.png`（完整提示词在 `dog-idle-prompt.txt`）；`wardrobe/accessories.png` 为领巾、草帽、围巾、毛线帽、雨披、睡帽。原图及完整提示词保留在 `wardrobe/prompts.json`。用 `python assets/pets/wardrobe/convert.py` 生成 `main/generated/ui_wardrobe_art.c/.h`。

切片按透明轮廓隔离邻帧；对相接的两帧按已知列边界拆分，再统一每行缩放与脚底基准，避免邻宠边缘混入。服装是独立透明层，运行时锚定头部/颈部，镜像适配行走方向。喂食、玩球、洗澡、睡眠和大幅伸展暂时不显示配饰，避免叠在脸或前爪上。未使用侵权游戏素材。

### 秋季围巾修正

秋季围巾已取消固定挂点贴图。`wardrobe/autumn-idle.png`、`wardrobe/autumn-walk.png` 使用内置 imagegen，以现有三宠动作表为参考重新绘制衣物；围巾与角色在同一帧内，毛发、耳朵和抬起的前爪都有正确的遮挡关系。原始输出及完整提示词保存在 `wardrobe/autumn-prompts.json`。正面、眨眼、转头、伸展、六帧步态均有对应造型，左行使用整帧镜像。

转换器按每个动画循环共用一套256色RGBA调色板，打包为LVGL原生I8图像，保留透明毛发边缘；54帧共639,360字节，比ARGB8888小约73%。运行时不再额外叠加旧围巾，也不会在伸展中突然脱掉围巾。睡觉和照料仍使用原有无服装动作，其他季节暂时保留独立配饰方案。

设置 `TT_PREVIEW_PROOF_DIR` 后运行 `ctest --test-dir build-pc -R preview_scene --output-on-failure`，可导出 `scarf-fit-0.bmp` 至 `scarf-fit-5.bmp`。每张按猫/狗/小鸡分行、待机/右行/左行分列，便于检查六个姿态的遮挡与步态。
