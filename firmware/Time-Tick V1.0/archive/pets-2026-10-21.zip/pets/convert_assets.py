"""Pack original source sheets into LVGL C data. Requires Python 3 and Pillow.

This only slices, aligns, resizes and converts generated artwork. A common crop
and scale is used for all frames in each row: no per-frame recentering/jitter.
Optional --proof writes contact sheets/GIFs into ignored build-assets/.
"""
from pathlib import Path
import argparse
from PIL import Image, ImageOps, ImageFilter, ImageChops

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
OUT=ROOT/'main'/'generated'
SIZE=104


def descriptor(name,image,alpha):
    w,h=image.size
    if alpha:
        raw=image.convert('RGBA').tobytes('raw','BGRA'); fmt,stride='ARGB8888',w*4
    else:
        raw=bytearray()
        for r,g,b in image.convert('RGB').get_flattened_data():
            v=((r>>3)<<11)|((g>>2)<<5)|(b>>3); raw.extend((v&255,v>>8))
        fmt,stride='RGB565',w*2
    lines=[f'static const uint8_t {name}_data[] = {{']
    lines+=['    '+','.join(f'0x{x:02x}' for x in raw[i:i+24])+',' for i in range(0,len(raw),24)]
    lines+=['};',f'const lv_image_dsc_t {name} = {{',
            f'    .header={{.magic=LV_IMAGE_HEADER_MAGIC,.cf=LV_COLOR_FORMAT_{fmt},.w={w},.h={h},.stride={stride}}},',
            f'    .data_size=sizeof({name}_data),.data={name}_data','};']
    return '\n'.join(lines)


def cell(sheet,col,row,cols,rows):
    return sheet.crop((round(col*sheet.width/cols),round(row*sheet.height/rows),
                       round((col+1)*sheet.width/cols),round((row+1)*sheet.height/rows)))


def bounds(im):
    box=im.getchannel('A').point(lambda a:255 if a>40 else 0).getbbox()
    if box is None: raise ValueError('Empty animation cell')
    return box


def extract_cells(sheet,rows,cols=6,split_wide=False):
    """Extract whole alpha islands, including props that cross a grid boundary.

    Generated sheets do not have exact gutters. Uniform cuts can include the
    next row's ears or cut a ball in half. Assign detached props to the closest
    character; keep original grid coordinates, so animation motion is retained.
    """
    w,h=sheet.size
    pixels=sheet.getchannel('A').tobytes()
    seen=bytearray(w*h); islands=[]
    for start in range(w*h):
        if seen[start] or pixels[start]<=40: continue
        seen[start]=1; stack=[start]; points=[]
        while stack:
            p=stack.pop(); points.append(p)
            x,y=p%w,p//w
            for q in ((p-1 if x else -1),(p+1 if x+1<w else -1),
                      (p-w if y else -1),(p+w if y+1<h else -1)):
                if q>=0 and not seen[q] and pixels[q]>40:
                    seen[q]=1; stack.append(q)
        if len(points)>=16:
            cx=sum(p%w for p in points)/len(points)
            cy=sum(p//w for p in points)/len(points)
            islands.append((points,cx,cy))
    if split_wide:
        separated=[]
        for points,cx,cy in islands:
            # Some generated neighbours touch at their ear edges. Slice those
            # joined islands at the known atlas boundary, retaining all other
            # islands and their original frame coordinates.
            if max(p%w for p in points)-min(p%w for p in points)>w/cols*1.6:
                groups={}
                for p in points: groups.setdefault(min(cols-1,p%w*cols//w),[]).append(p)
                for group in groups.values():
                    separated.append((group,sum(p%w for p in group)/len(group),sum(p//w for p in group)/len(group)))
            else: separated.append((points,cx,cy))
        islands=separated
    bodies={}
    for island in islands:
        points,cx,cy=island
        key=(min(cols-1,int(cx*cols/w)),min(rows-1,int(cy*rows/h)))
        if len(points)>len(bodies.get(key,([],0,0))[0]): bodies[key]=island
    if len(bodies)!=cols*rows: raise ValueError(f'Expected {cols*rows} character silhouettes')
    masks={key:bytearray(w*h) for key in bodies}
    for points,cx,cy in islands:
        key=min(bodies,key=lambda k:(cx-bodies[k][1])**2+(cy-bodies[k][2])**2)
        for p in points: masks[key][p]=255
    result={}
    for (col,row),raw in masks.items():
        mask=Image.frombytes('L',(w,h),bytes(raw)).filter(ImageFilter.MaxFilter(7))
        isolated=sheet.copy()
        isolated.putalpha(ImageChops.multiply(sheet.getchannel('A'),mask))
        pad=32
        result[col,row]=isolated.crop((round(col*w/cols)-pad,round(row*h/rows)-pad,
                                      round((col+1)*w/cols)+pad,round((row+1)*h/rows)+pad))
    return result


def align_row(frames):
    boxes=[bounds(f) for f in frames]
    crop=(min(b[0] for b in boxes),min(b[1] for b in boxes),max(b[2] for b in boxes),max(b[3] for b in boxes))
    scale=min(96/(crop[2]-crop[0]),92/(crop[3]-crop[1]))
    width,height=round((crop[2]-crop[0])*scale),round((crop[3]-crop[1])*scale)
    result=[]
    for f in frames:
        sprite=Image.new('RGBA',(SIZE,SIZE))
        resized=f.crop(crop).resize((width,height),Image.Resampling.LANCZOS)
        sprite.alpha_composite(resized,((SIZE-width)//2,98-height)); result.append(sprite)
    if len({im.tobytes() for im in result})!=6: raise ValueError('Repeated animation frames')
    return result


def main():
    parser=argparse.ArgumentParser(); parser.add_argument('--proof',action='store_true'); args=parser.parse_args()
    OUT.mkdir(parents=True,exist_ok=True)
    declarations=['#pragma once','#include "lvgl.h"',
                  'extern const lv_image_dsc_t *const tt_art_pets[3][3];',
                  'extern const lv_image_dsc_t *const tt_art_motion[3][5][6];']
    base=['/* Generated by assets/pets/convert_assets.py. */','#include "ui_art.h"']
    sheet=Image.open(HERE/'pets.png').convert('RGBA')
    idle_cells=extract_cells(sheet,3,4)
    for row in range(3):
        for index,col in enumerate((0,2,3)):
            original=idle_cells[col,row]; crop=original.crop(bounds(original))
            crop.thumbnail((94,65 if col==3 else 90),Image.Resampling.LANCZOS)
            sprite=Image.new('RGBA',(SIZE,SIZE)); sprite.alpha_composite(crop,((SIZE-crop.width)//2,98-crop.height))
            base.append(descriptor(f'tt_art_pet_{row}_{index}',sprite,True))
    base.append('const lv_image_dsc_t *const tt_art_pets[3][3] = {')
    for row in range(3): base.append('    {'+','.join(f'&tt_art_pet_{row}_{i}' for i in range(3))+'},')
    base.append('};')
    (OUT/'ui_art.c').write_text('\n\n'.join(base)+'\n',encoding='utf-8')
    motion=['/* Generated by assets/pets/convert_assets.py. */','#include "ui_art.h"']
    gait=Image.open(HERE/'walk-cycle.png').convert('RGBA')
    gait_cells=extract_cells(gait,3)
    proof=ROOT/'build-assets'
    if args.proof: proof.mkdir(exist_ok=True)
    for pet,species in enumerate(('cat','dog','chick')):
        actions=Image.open(HERE/f'{species}-actions.png').convert('RGBA')
        extracted=extract_cells(actions,4)
        clips=[align_row([gait_cells[i,pet] for i in range(6)])]
        clips += [align_row([extracted[i,row] for i in range(6)]) for row in (1,2,3)]
        clips.append([ImageOps.mirror(frame) for frame in clips[0]])
        contact=Image.new('RGB',(SIZE*6,SIZE*5),(230,239,217))
        for clip,frames in enumerate(clips):
            for frame,im in enumerate(frames):
                motion.append(descriptor(f'tt_motion_{pet}_{clip}_{frame}',im,True))
                if args.proof: contact.paste(im,(frame*SIZE,clip*SIZE),im)
            if args.proof:
                animated=[]
                for im in frames:
                    canvas=Image.new('RGB',(SIZE,SIZE),(230,239,217)); canvas.paste(im,(0,0),im); animated.append(canvas)
                animated[0].save(proof/f'{species}-{clip}.gif',save_all=True,append_images=animated[1:],duration=125 if clip in (0,4) else 150,loop=0)
        if args.proof: contact.save(proof/f'{species}-contact.png')
    motion.append('const lv_image_dsc_t *const tt_art_motion[3][5][6] = {')
    for pet in range(3):
        motion.append('    {')
        for clip in range(5): motion.append('        {'+','.join(f'&tt_motion_{pet}_{clip}_{f}' for f in range(6))+'},')
        motion.append('    },')
    motion.append('};')
    (OUT/'ui_motion.c').write_text('\n\n'.join(motion)+'\n',encoding='utf-8')
    (OUT/'ui_art.h').write_text('\n'.join(declarations)+'\n',encoding='utf-8')
    print('Packed 9 idle poses, 72 action frames and 18 mirrored walk frames. Backgrounds are in assets/weather.')
    print('Pixel bytes:',99*SIZE*SIZE*4)


if __name__=='__main__': main()
