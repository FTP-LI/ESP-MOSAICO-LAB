# 桌宠天气小道具

2026-10-20 使用 Codex 内置 **imagegen** 生成两张透明插画；未使用 CLI 或第三方游戏素材。选定原图留存在本目录，生成工具的原始副本也保留。完整最终提示词见 [prompts.json](prompts.json)。

| 原图 | 用途 | 固件尺寸 |
| --- | --- | --- |
| `rain-parasol.png` | 雨天/雷雨的固定侧柱小伞，位于伙伴后方；雷雨时原生渲染加少量绿灰色调 | 120×116 |
| `winter-cushion.png` | 雪天蜷卧时的针织软垫，起身走动时隐藏 | 104×25 |

从软件项目目录执行：

```powershell
python assets/pets/weather/convert_weather_props.py
```

转换器只按透明轮廓裁去空白边缘、等比缩小并打包，不重绘源图。输出 `main/generated/ui_pet_weather_art.c/.h`，两张 ARGB8888 像素共66,080字节。PC与固件共用，不需文件系统或运行时PNG解码。

蝴蝶、轻风、白雾和小灯由 `main/ui/ui_pet_weather.c` 原生绘制，复用小院50ms更新。小伞固定在进入雨天时的停留/行走目标位置，点草地召唤后伙伴会自行走回伞下，不把伞当随身贴纸移动。所有天气表现均不扣成长数值；规则见 [陪伴说明](../../../docs/PET_CARE.md)。
